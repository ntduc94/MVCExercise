﻿using System;

namespace Day3_Assigment3
{
    class Country
    {
        /// <summary>
        /// Code of Country
        /// </summary>
        public string countryCode;

        /// <summary>
        /// Name of Country
        /// </summary>
        public string countryName;

        /// <summary>
        /// Area of Country
        /// </summary>
        public float totalArea;

        /// <summary>
        /// Constructor without parameters of Country
        /// </summary>
        public Country()
        {

        }

        /// <summary>
        /// Constructor with parameters of Country
        /// </summary>
        /// <param name="countryCode"></param>
        /// <param name="countryName"></param>
        /// <param name="totalArea"></param>
        public Country(string countryCode, string countryName, float totalArea)
        {
            this.countryCode = countryCode;
            this.countryName = countryName;
            this.totalArea = totalArea;
        }

        /// <summary>
        /// Display the information of Country
        /// </summary>
        public virtual void Display()
        {
            Console.Write($"Country Name: {countryName}, Code: {countryCode}, Area: {totalArea}");
        }
    }
}
