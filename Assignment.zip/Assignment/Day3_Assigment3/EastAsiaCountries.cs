﻿using System;

namespace Day3_Assigment3
{
    class EastAsiaCountries : Country
    {
        /// <summary>
        /// Terrain of country
        /// </summary>
        public string countryTerrain;

        /// <summary>
        /// Constructor of East Asia Country
        /// </summary>
        /// <param name="countryCode"></param>
        /// <param name="countryName"></param>
        /// <param name="totalArea"></param>
        /// <param name="countryTerrain"></param>
        public EastAsiaCountries(string countryCode, string countryName, float totalArea, string countryTerrain) : base(countryCode, countryName, totalArea)
        {
            this.countryTerrain = countryTerrain;
        }

        /// <summary>
        /// Show infomation of a EastAsia country.
        /// </summary>
        public override void Display()
        {
            base.Display();
            Console.WriteLine($", Terrain: {countryTerrain}");
        }
    }
}
