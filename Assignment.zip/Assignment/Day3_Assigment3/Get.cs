﻿using System;

namespace Day3_Assigment3
{
    static class Get
    {
        /// <summary>
        /// String from console must not null.
        /// </summary>
        /// <returns></returns>
        public static string Required()
        {
            string inputString;
            do
            {
                inputString = Console.ReadLine();
                if (inputString == null || inputString == "") Console.Write("This is required! Try again: ");
            } while (inputString == null || inputString == "");
            return inputString;
        }

        /// <summary>
        /// Require a number from console.
        /// </summary>
        /// <returns></returns>
        public static double NumberValue()
        {
            try
            {
                string input = Required();
                return Convert.ToDouble(input);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Require a string from console.
        /// </summary>
        /// <returns></returns>
        public static string StringValue()
        {
            return Required();
        }
    }
}
