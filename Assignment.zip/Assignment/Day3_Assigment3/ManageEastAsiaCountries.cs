﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Day3_Assigment3
{
    class ManageEastAsiaCountries
    {
        /// <summary>
        /// List of EastAsia Countries
        /// </summary>
        private List<EastAsiaCountries> eastAsiaCountries;

        /// <summary>
        /// Constructor of Manage EastAsia Countries
        /// </summary>
        public ManageEastAsiaCountries()
        {
            eastAsiaCountries = new List<EastAsiaCountries>();
        }

        /// <summary>
        /// Input the information of 11 countries in East Asia.
        /// </summary>
        public void AddCountryInformation()
        {
            try
            {
                Console.Write("Enter code of country: ");
                string code = Get.StringValue();
                Console.Write("Enter name of country: ");
                string name = Get.StringValue();
                Console.Write("Enter area of country: ");
                float area = (float)Get.NumberValue();
                Console.Write("Enter terrain of country: ");
                string terrain = Get.StringValue();

                eastAsiaCountries.Add(new EastAsiaCountries(code, name, area, terrain));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// Display the information of country you've just input.
        /// </summary>
        public EastAsiaCountries GetRecentlyEnteredInformation()
        {
            return eastAsiaCountries.LastOrDefault();
        }

        /// <summary>
        /// Search the information of country by user-entered name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public EastAsiaCountries[] SearchInformationByName(string name)
        {
            return eastAsiaCountries.FindAll(c => c.countryName.Equals(name)).ToArray();
        }

        /// <summary>
        /// Hiển thị thông tin tăng dần theo tên đất nước.
        /// </summary>
        /// <param name="countries"></param>
        public void DisplayCountries(List<EastAsiaCountries> countries)
        {
            countries.ForEach(c => c.Display());
        }

        /// <summary>
        /// Display the information of countries sorted name in ascending order.
        /// </summary>
        /// <returns></returns>
        public EastAsiaCountries[] SortInformationByAscendingOrder()
        {
            return eastAsiaCountries.OrderBy(x => x.countryName).ToArray();
        }
    }
}
