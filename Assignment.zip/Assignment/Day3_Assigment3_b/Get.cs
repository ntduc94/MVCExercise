﻿using System;

namespace Day3_Assigment3
{
    static class Get
    {
        /// <summary>
        /// Check input is a empty or null string, if not, get a string from console.
        /// </summary>
        /// <returns></returns>
        public static string Required()
        {
            string inputString;
            do
            {
                inputString = Console.ReadLine();
                if (inputString == null || inputString == "") Console.Write("This is required! Try again: ");
            } while (inputString == null || inputString == "");
            return inputString;
        }

        /// <summary>
        /// Throw a exception if not a number, return a double number.
        /// </summary>
        /// <returns></returns>
        public static double NumberValue()
        {
            try
            {
                string input = Required();
                return Convert.ToDouble(input);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get a string from console
        /// </summary>
        /// <returns></returns>
        public static string StringValue()
        {
            return Required();
        }
    }
}
