﻿using System;

namespace Day3_Assigment3
{
    class Program
    {
        /// <summary>
        /// Initial Manage EastAsia Countries
        /// </summary>
        static ManageEastAsiaCountries manageEastAsiaCountries = new ManageEastAsiaCountries();
        static void Main(string[] args)
        {
            //Run();
                try
                {
                    int m = Int32.Parse("   11");
                Console.WriteLine(m);
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
        }

        /// <summary>
        /// Run the application
        /// </summary>
        private static void Run()
        {
            bool flag = true;

            Console.WriteLine("                              MENU                                  ");
            Console.WriteLine("====================================================================");
            Console.WriteLine("1. Input the information of 11 countries in East Asia               ");
            Console.WriteLine("2. Dislay the information of country you've just input              ");
            Console.WriteLine("3. Search the information of country by user-entered name           ");
            Console.WriteLine("4. Display the information of country sorted name is ascending order");
            Console.WriteLine("5. Exit                                                             ");
            Console.WriteLine("====================================================================");
            do
            {
                Console.Write("Number of menu: ");

                int switch_on = Convert.ToInt32(Get.NumberValue());
                switch (switch_on)
                {
                    case 1:
                        manageEastAsiaCountries.AddCountryInformation();
                        break;
                    case 2:
                        manageEastAsiaCountries.GetRecentlyEnteredInformation().Display();
                        break;
                    case 3:
                        Console.Write("Nhap ten: ");
                        foreach (var item in manageEastAsiaCountries.SearchInformationByName(Get.StringValue()))
                        {
                            item.Display();
                        }
                        break;
                    case 4:
                        foreach (var item in manageEastAsiaCountries.SortInformationByAscendingOrder())
                        {
                            item.Display();
                        }
                        break;
                    case 5:
                        flag = false;
                        break;
                    default:
                        Console.Write("Just 1 to 5! ");
                        break;
                }
            } while (flag);
        }
    }
}
