﻿using System;
using System.Text.RegularExpressions;

namespace Day3_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Run();
        }

        /// <summary>
        /// Run the Program
        /// </summary>
        private static void Run()
        {
            Console.WriteLine("====== Validate Progaram ======");
            do
            {
                Console.Write("Phone number: ");
            } while (!Validation.IsPhone(Console.ReadLine()));
            Console.WriteLine("Insert success!");

            do
            {
                Console.Write("Email: ");
            } while (!Validation.IsMail(Console.ReadLine()));
            Console.WriteLine("Insert success!");

            do
            {
                Console.Write("Date: ");
            } while (!Validation.IsDate(Console.ReadLine()));
            Console.WriteLine("Insert success!");
        }
    }
}
