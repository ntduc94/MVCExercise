﻿using System;
using System.Text.RegularExpressions;

namespace Day3_Assignment2
{
    static class Validation
    {
        /// <summary>
        /// True for input string is a date
        /// </summary>
        /// <param name="inputString"></param>
        /// <returns></returns>
        internal static bool IsDate(string inputString)
        {
            if (Regex.IsMatch(inputString, @"^([0]?[0-9]|[12][0-9]|[3][01])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$"))
                return true;
            else Console.WriteLine("Date to correct format(dd/mm/yyyy) ");
            return false;
        }

        /// <summary>
        /// True for input string is a Phone Number
        /// </summary>
        /// <param name="inputString"></param>
        /// <returns></returns>
        internal static bool IsPhone(string inputString)
        {
            if (Regex.IsMatch(inputString, @"^(\(?\+?[0-9]*\)?)?[0-9_\- \(\)]*$"))
            {
                if (inputString.Length != 10) Console.WriteLine("Phone number must be 10 digits");
                else return true;
            }
            else Console.WriteLine("Phone number must is number");
            return false;
        }

        /// <summary>
        /// True for input string is Email Address
        /// </summary>
        /// <param name="inputString"></param>
        /// <returns></returns>
        internal static bool IsMail(string inputString)
        {
            if (Regex.IsMatch(inputString, @"^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@"
                                         + @"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				                                    [0-9]{1,2}|25[0-5]|2[0-4][0-9])\."
                                         + @"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				                                    [0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                                         + @"([a-zA-Z0-9]+[\w-]+\.)+[a-zA-Z]{1}[a-zA-Z0-9-]{1,23})$"))
                return true;
            else Console.WriteLine("Date to correct format(dd/mm/yyyy) ");
            return false;
        }
    }
}
