﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Day4_Assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet dataSet = new DataSet();

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
            AddBindingTextbox();
        }

        private void searchTextbox_TextChanged(object sender, EventArgs e)
        {
            dataSet.Tables[0].DefaultView.RowFilter = $"Name like '%{searchTextbox.Text}%'";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateNhanVien();
            LoadData();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            InsertNhanVien();
            LoadData();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
            ClearTextbox();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteNhanVien();
            LoadData();
        }

        private void AddBindingTextbox()
        {
            txtId.DataBindings.Add("Text", bindingSource1, "Id");
            txtName.DataBindings.Add("Text", bindingSource1, "Name");
            txtDoB.DataBindings.Add("Text", bindingSource1, "DoB");
            txtAddress.DataBindings.Add("Text", bindingSource1, "Address");
            txtSalary.DataBindings.Add("Text", bindingSource1, "Salary");
        }

        private void ClearTextbox()
        {
            txtId.Clear();
            txtName.Clear();
            txtDoB.Clear();
            txtAddress.Clear();
            txtSalary.Clear();
        }

        private void LoadData()
        {
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["D4Ass1ConnectionString"].ConnectionString;
            command.Connection = connection;
            command.CommandText = "select * from NhanVien";
            command.CommandType = CommandType.Text;
            adapter.SelectCommand = command;
            if (dataSet.Tables.Count > 0) dataSet.Tables[0].Clear();
            adapter.Fill(dataSet);

            bindingSource1.DataSource = dataSet.Tables[0].DefaultView;
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
        }

        private void DeleteNhanVien()
        {
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["D4Ass1ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand()
                {
                    CommandText = "delete from NhanVien where Id = @Id",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters = { new SqlParameter("@Id", txtId.Text) }
                };

                connection.Open();

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void UpdateNhanVien()
        {
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["D4Ass1ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand()
                {
                    CommandText = "Update NhanVien set Name = @Name, DoB = @DoB, Address = @Address, Salary = @Salary where Id = @Id",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters =
                    {
                        new SqlParameter("@Name", txtName.Text),
                        new SqlParameter("@DoB", txtDoB.Text),
                        new SqlParameter("@Address", txtAddress.Text),
                        new SqlParameter("@Salary", txtSalary.Text),
                        new SqlParameter("@Id", txtId.Text)
                    }
                };

                connection.Open();

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void InsertNhanVien()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["D4Ass1ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand()
                {
                    CommandText = "insert into NhanVien (Name, DoB, Address, Salary) values (@Name, @DoB, @Address, @Salary)",
                    CommandType = CommandType.Text,
                    Connection = conn,
                    Parameters =
                    {
                        new SqlParameter("@Name", txtName.Text),
                        new SqlParameter("@DoB", txtDoB.Text),
                        new SqlParameter("@Address", txtAddress.Text),
                        new SqlParameter("@Salary", txtSalary.Text)
                    }
                };

                conn.Open();

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
