﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Day4_Assignment1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DisplayData();
        }

        /// <summary>
        /// SQL Connection String
        /// </summary>
        string connectionString = @"Data Source=CPP00124453AC\DUCNT38;Initial Catalog=D4Ass1;Persist Security Info=True;User ID=sa;Password=Lbbu8btd;";

        /// <summary>
        /// ID variable used in Updating and Deleting Record 
        /// </summary>
        int Id = 0;

        //Insert Data  
        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (textName.Text != "" && textName.Text != "")
            {
                InsertData();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        //Update Record  
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (textName.Text != "" && textDoB.Text != "" && textAddress.Text != "" && textSalary.Text != "")
            {
                UpdateRecord();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }

        //Delete Record  
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (Id != 0)
            {
                DeleteRecord();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //textName.Text = e.RowIndex.ToString();
            Id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textDoB.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textAddress.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textSalary.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void DeleteRecord()
        {
            using (var connection = new SqlConnection(@"Data Source=CPP00124453AC\DUCNT38;Initial Catalog=D4Ass1;Persist Security Info=True;User ID=sa;Password=Lbbu8btd;"))
            {
                var command = new SqlCommand
                {
                    CommandText = "delete from NhanVien where Id = @Id",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters = { new SqlParameter("@Id", Id) }
                };

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private void UpdateRecord()
        {
            using (var connection = new SqlConnection(@"Data Source=CPP00124453AC\DUCNT38;Initial Catalog=D4Ass1;Persist Security Info=True;User ID=sa;Password=Lbbu8btd;"))
            {
                var command = new SqlCommand
                {
                    CommandText = "update NhanVien set Name = @Name, DoB = @DoB, Address = @Address, Salary = @Salary where Id = @Id",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters =
                    {
                        new SqlParameter("@Id", Id),
                        new SqlParameter("@Name", textName.Text),
                        new SqlParameter("@DoB", textDoB.Text),
                        new SqlParameter("@Address", textAddress.Text),
                        new SqlParameter("@Salary", textSalary.Text)
                    }
                };

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
            }
        }

        private void InsertData()
        {
            using (var connection = new SqlConnection(@"Data Source=CPP00124453AC\DUCNT38;Initial Catalog=D4Ass1;Persist Security Info=True;User ID=sa;Password=Lbbu8btd;"))
            {
                var command = new SqlCommand
                {
                    CommandText = "insert into NhanVien (Name, DoB, Address, Salary) values (@Name, @DoB, @Address, @Salary)",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters =
                        {
                            new SqlParameter("@Name", textName.Text),
                            new SqlParameter("@DoB", textDoB.Text),
                            new SqlParameter("@Address", textAddress.Text),
                            new SqlParameter("@Salary", textSalary.Text)
                        }
                };

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Record Inserted Successfully");
            }
        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var adapter = new SqlDataAdapter("select * from NhanVien", connection);
                var dataSet = new DataSet();
                adapter.Fill(dataSet);
                dataGridView1.DataSource = dataSet.Tables[0].DefaultView;
            }
        }
        //Clear Data in Textbox
        private void ClearData()
        {
            textName.Text = "";
            textDoB.Text = "";
            textAddress.Text = "";
            textSalary.Text = "";
            Id = 0;
        }
    }
}
