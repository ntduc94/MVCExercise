﻿using System;

namespace Day4_Assignment2
{
    public static class ConsoleReadKey
    {
        /// <summary>
        /// String from console must not null.
        /// </summary>
        /// <returns></returns>
        public static string Required()
        {
            string inputString;
            do
            {
                inputString = Console.ReadLine();
                if (inputString == null || inputString == "") Console.WriteLine("This is required!");
            } while (inputString == null || inputString == "");
            return inputString;
        }

        /// <summary>
        /// Require a number from console.
        /// </summary>
        /// <returns></returns>
        public static double GetNumber()
        {
            bool isNumber = true;
            double number = 0;
            do
            {
                isNumber = Double.TryParse(Required(), out number);
                if (!isNumber)
                    Console.WriteLine("ID is digit");
            } while (!isNumber);

            return number;
        }

        /// <summary>
        /// Require a string from console.
        /// </summary>
        /// <returns></returns>
        public static string GetString()
        {
            return Required();
        }
    }
}