﻿namespace Day4_Assignment2
{
    /// <summary>
    /// Contact Class
    /// </summary>
    public class Contact
    {
        // Contact property
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Group { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }

        /// <summary>
        /// To string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Id: {Id}, Name: {FirstName} {LastName}, Group: {Group}, Address: {Address}, Phone: {Phone}";
        }
    }
}
