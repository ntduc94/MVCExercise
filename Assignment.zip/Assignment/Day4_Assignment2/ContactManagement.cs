﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Day4_Assignment2
{
    class ContactManagement
    {
        private DBConnection dbConnection;

        /// <summary>
        /// Constructor for Contact Management, initial dbConnection with Connection String
        /// </summary>
        public ContactManagement()
        {
            dbConnection = new DBConnection { ConnectionString = @"Data Source=CPP00124453AC\DUCNT38;Initial Catalog=ContactDB;Persist Security Info=True;User ID=sa;Password=Lbbu8btd;" };
        }

        /// <summary>
        /// Add contact to list
        /// </summary>
        public void AddContact()
        {
            Contact contact = new Contact();
            try
            {
                // Enter contact name
                Console.Write("Enter Name: ");
                string[] name = ConsoleReadKey.GetString().Split(' ');
                contact.FirstName = name[0];

                if (name.Count() < 1)
                {
                    contact.LastName = name[1];
                }
                else
                {
                    contact.LastName = "";
                }                

                // Enter contact address
                Console.Write("Enter Address: ");
                contact.Address = ConsoleReadKey.GetString();

                // Enter contact group
                Console.Write("Enter Group: ");
                contact.Group = ConsoleReadKey.GetString();

                // Enter contact phone
                bool isPhone = true;
                do
                {
                    Console.Write("Enter Phone: ");
                    contact.Phone = ConsoleReadKey.GetString();
                    isPhone = Regex.IsMatch(contact.Phone, @"^\(?([0-9]{3})\)?[.\-\s]?([0-9]{3})[.\-\s]?([0-9]{4})\s?([ext1234])?");
                    if (!isPhone)
                    {
                        Console.WriteLine("Please input Phone flow");
                        Console.WriteLine(" - 1234567890");
                        Console.WriteLine(" - 123-456-7890");
                        Console.WriteLine(" - 123-456-7890 x1234");
                        Console.WriteLine(" - 123-456-7890 ext1234");
                        Console.WriteLine(" - (123)-456-7890");
                        Console.WriteLine(" - 123.456.7890");
                        Console.WriteLine(" - 123 456 7890");
                    }
                } while (!isPhone);

                dbConnection.InsertContact(contact);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// Display all the contact
        /// </summary>
        public void DisplayAll()
        {
            foreach (var item in dbConnection.GetAllContact())
            {
                Console.WriteLine(item);
            }
        }

        /// <summary>
        /// Delete a contact
        /// </summary>
        public void DeleteContact()
        {
            Console.WriteLine("Enter ID: ");
            int Id = Convert.ToInt32(ConsoleReadKey.GetNumber());
            dbConnection.DeleteContact(Id);
        }
    }
}
