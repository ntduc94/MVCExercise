﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Day4_Assignment2
{
    class DBConnection
    {
        public string ConnectionString { get; set; }

        /// <summary>
        /// Get all contact from database
        /// </summary>
        /// <returns></returns>
        public List<Contact> GetAllContact()
        {
            List<Contact> contacts = new List<Contact>();
            using (var connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    var adapter = new SqlDataAdapter("select * from Contact", connection);
                    var table = new DataTable();
                    adapter.Fill(table);

                    foreach (System.Data.DataRow row in table.Rows)
                    {
                        contacts.Add(new Contact
                        {
                            Id = Convert.ToInt32(row[0]),
                            FirstName = row[1].ToString(),
                            LastName = row[2].ToString(),
                            Group = row[3].ToString(),
                            Address = row[4].ToString(),
                            Phone = row[5].ToString()
                        });
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return null;
                }

                return contacts;
            }
        }

        /// <summary>
        /// Insert a contact to database 
        /// </summary>
        /// <param name="contact"></param>
        public void InsertContact(Contact contact)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                var command = new SqlCommand
                {
                    CommandText = "insert into Contact (FirstName, LastName, [Group], [Address], Phone) values (@FirstName, @LastName, @Group, @Address, @Phone)",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters =
                        {
                            new SqlParameter("@FirstName", contact.FirstName),
                            new SqlParameter("@LastName", contact.LastName),
                            new SqlParameter("@Group", contact.Group),
                            new SqlParameter("@Address", contact.Address),
                            new SqlParameter("@Phone", contact.Phone)
                        }
                };

                connection.Open();
                command.ExecuteNonQuery();
                Console.WriteLine("Successful");
            }
        }

        /// <summary>
        /// Delete a contact from database
        /// </summary>
        /// <param name="Id"></param>
        public void DeleteContact(int Id)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                var command = new SqlCommand
                {
                    CommandText = "delete from Contact where Id = @Id",
                    CommandType = CommandType.Text,
                    Connection = connection,
                    Parameters = { new SqlParameter("@Id", Id) }
                };

                connection.Open();
                command.ExecuteNonQuery();
            }
            Console.WriteLine("Successful");
        }
    }
}
