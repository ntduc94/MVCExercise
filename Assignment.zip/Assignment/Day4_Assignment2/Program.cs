﻿using System;

namespace Day4_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Run();
            //DBConnection dBConnection = new DBConnection();
            //dBConnection.ConnectionString = @"Data Source=CPP00124453AC\DUCNT38;Initial Catalog=ContactDB;Persist Security Info=True;User ID=sa;Password=Lbbu8btd;";
            //dBConnection.GetAllContact();
        }

        private static void Run()
        {
            //Contact
            //1.Thêm một contact.
            //2.Hiển thị tất cả danh bạ
            //3.Xóa một contact.
            //4.Thoát

            bool flag = true;

            var contactManagement = new ContactManagement();
            do
            {
                Console.WriteLine("========= Contact program =========");
                Console.WriteLine("1. Add a Contact");
                Console.WriteLine("2. Display all Contact");
                Console.WriteLine("3. Delete a Contact");
                Console.WriteLine("4. Exit");
                Console.WriteLine("===================================");
                Console.Write("Number of menu: ");

                int switch_on = Convert.ToInt32(ConsoleReadKey.GetNumber());
                switch (switch_on)
                {
                    case 1:
                        Console.WriteLine("-------- Add a Contact --------");
                        contactManagement.AddContact();
                        break;
                    case 2:
                        Console.WriteLine("--------------------------------- Display all Contact ----------------------------");
                        contactManagement.DisplayAll();
                        break;
                    case 3:
                        Console.WriteLine("------- Delete a Contact -------");
                        contactManagement.DeleteContact();
                        break;
                    case 4:
                        flag = false;
                        break;
                    default:
                        Console.Write("Just 1 to 4!");
                        break;
                }
            } while (flag);
        }
    }
}
