﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opt2
{
    public class Contact
    {

        public int ID { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Group { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }

        public Contact()
        {

        }

        public Contact(int id, string name,string firstname, string lastname, string group, string address, string phone)
        {
            ID = id;
            Name = name;
            FirstName = firstname;
            LastName = lastname;
            Group = group;
            Address = address;
            Phone = phone;
        }

        public Contact(string firstname, string lastname, string group, string address, string phone)
        {
            FirstName = firstname;
            LastName = lastname;
            Group = group;
            Address = address;
            Phone = phone;

            Name = firstname.ToString().Trim() + " " + lastname.ToString().Trim();
        }

        //ToString
        public override string ToString()
        {
            return string.Format("{0}  {1}  {2}  {3}  {4}  {5}  {6}",ID.ToString(),Name, FirstName, LastName, Group,Address,Phone);
        }
    }
}
