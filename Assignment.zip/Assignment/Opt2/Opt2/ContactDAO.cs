﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Opt2
{
    public class ContactDAO
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=PhoneBook;Integrated Security=True");


        //Add
        public int Add(Contact contact)
        {
            try
            {
                string sql = string.Format("INSERT INTO[dbo].[Contact]([ID],[Name],[First Name],[LastName],[Group],[Address],[Phone])VALUES({0},N'{1}',N'{2}',N'{3}',N'{4}',N'{5}','{6}')",GetMaxID()+1, contact.Name, contact.FirstName, contact.LastName, contact.Group, contact.Address, contact.Phone);
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                int kq= cmd.ExecuteNonQuery();
                con.Close();
                return kq;
            }
            catch
            {
                return 0;
            }
        }

        // To list
        public List<Contact> ToList()
        {
            try
            {
                string sql = string.Format("SELECT [ID],[Name],[First Name],[LastName],[Group],[Address],[Phone] FROM [PhoneBook].[dbo].[Contact]");
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataAdapter adap = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adap.Fill(dt);
                return ToList(dt);
            }
            catch
            {
                return null;
            }
        }

        //Covert datatable to list
        private List<Contact> ToList(DataTable dt)
        {
            List<Contact> conlst = new List<Contact>();
            if(dt.Rows.Count>0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    var r = dt.Rows[i];
                    Contact contact = new Contact(int.Parse(r[0].ToString()), r[1].ToString(), r[2].ToString(), r[3].ToString(), r[4].ToString(), r[5].ToString(), r[6].ToString());
                    conlst.Add(contact);
                }
                return conlst;
            }
            else
            {
                return new List<Contact>();
            }
        }

        // Get max ID
        private int GetMaxID()
        {
            try
            {
                string sql = string.Format("SELECT MAX(ID) FROM [dbo].Contact");
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                int kq = int.Parse(cmd.ExecuteScalar().ToString());
                con.Close();
                return kq;
            }



            catch
            {
                return 0;
            }
        }

        // Delete
        public bool Delete(int ID)
        {
            try
            {
                string sql = string.Format("DELETE FROM [dbo].[Contact] WHERE ID={0}", ID);
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                int kq = cmd.ExecuteNonQuery();
                con.Close();
                if(kq>0)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
