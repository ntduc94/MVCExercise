﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opt2
{
    class Program
    {      
        static void Main(string[] args)
        {
            ContactDAO contactDAO = new ContactDAO();
            List<Contact> PhoneBook = contactDAO.ToList();
            int key = 0;
            do
            {
                Console.Clear();
                Console.WriteLine("---------- PHONE BOOK ----------");
                Console.WriteLine("1. Them mot contact.");
                Console.WriteLine("2. Hien thi tat ca danh ba.");
                Console.WriteLine("3. Xoa mot contact.");
                Console.WriteLine("4. Thoat.");

                key = int.Parse(Console.ReadLine());

                switch(key)
                {
                    case 1:
                        {
                            Console.Clear();
                            Console.WriteLine("--- Them moi mot contact ---");
                            Console.WriteLine("Nhap first name:");
                            string firstname= Console.ReadLine();
                            Console.WriteLine("Nhap last name");
                            string lastname= Console.ReadLine();
                            Console.WriteLine("Nhap ten group");
                            string group=Console.ReadLine();
                            Console.WriteLine("Nhap dia chi");
                            string address= Console.ReadLine();
                            Console.WriteLine("Nhap number phone");
                            string phone= Console.ReadLine();

                            Contact con = new Contact(firstname, lastname, group, address, phone);
                            if (contactDAO.Add(con) > 0)
                            {
                                Console.WriteLine("Them thanh cong!");
                            }
                            else
                            {
                                Console.WriteLine("Co loi xay ra, vui long kiem tra va thu lai!");
                            }                            
                        }
                        break;
                    case 2:
                        {
                            Console.Clear();
                            if(PhoneBook.Count()>0)
                            {
                                foreach (var item in PhoneBook)
                                {
                                    Console.WriteLine(item.ToString());
                                }
                            }
                            else
                            {
                                Console.WriteLine("Danh sach trong");
                            }

                            Console.ReadKey();
                        }
                        break;
                    case 3:
                        {
                            Console.Clear();
                            int ID=-1;
                            do
                            {
                                Console.WriteLine("---------- Xoa Mot Contact ----------");
                                Console.WriteLine("Nhap ID Contact muon xoa:");
                                try
                                {
                                    ID = int.Parse(Console.ReadLine().ToString());
                                }
                                catch { }
                            }
                            while (ID<0);
                            if(contactDAO.Delete(ID))
                            {
                                Console.WriteLine("Xoa thanh cong!");
                            }
                            else
                            {
                                Console.WriteLine("ID khong ton tai");
                            }
                        }
                        break;
                }
                Console.ReadKey();
            } while(key != 4);
        }

        static void AddContact()
        {
            Console.Clear();
        }
    }
}
