﻿using BOL;
using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace BAL
{
    public class WorkerBAL
    {
        public string ConnectionString { get; set; }
        List<SalaryHistory> salaryHistory = new List<SalaryHistory>();
        public bool AddWorker(Worker worker)
        {
            //Exception("Data doesn't exist") nếu worker null.
            try
            {

            }
            catch (ArgumentNullException e)
            {

                throw e;
            }
            //Exception("Code is not null") Nếu code worker bị null.
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
            //Exception("Duplicate code") Nếu code worker đã tồn tại.



            return false;
        }

        public List<Worker> DisplayInfomationWorker()
        {
            List<Worker> workers = new List<Worker>();
            foreach (DataRow row in WorkerDAL.ReturnWorkerDataTable(ConnectionString).Rows)
            {
                workers.Add(new Worker
                {
                    Name = row[0].ToString(),
                    Age = Convert.ToInt32(row[0].ToString()),
                    Salary = Convert.ToDouble(row[0].ToString()),
                    WorkLocation = row[0].ToString()
                });
            }
            workers = workers.OrderBy(x => x.Salary).ToList();
            return workers;
        }

        public bool ChangeSalary(SalaryStatus status, int id, double amount)
        {
            salaryHistory.Add(new SalaryHistory { Status = status, Id = id, Amount = amount });
            Worker worker = FindWorkerById(id);
            switch (status)
            {
                case SalaryStatus.Increase:
                    worker.Salary += amount;
                    break;
                case SalaryStatus.Decrease:
                    worker.Salary -= amount;
                    break;
                default:
                    break;
            }

            if (WorkerDAL.AddWorker(ConnectionString, worker) > 0)
                return true;

            return false;
        }

        public List<SalaryHistory> DisplayInfomationSalary()
        {
            return salaryHistory;
        }

        public Worker FindWorkerById(int id)
        {            
            return DisplayInfomationWorker().Find(x => x.Id == id);
        }
    }
}
