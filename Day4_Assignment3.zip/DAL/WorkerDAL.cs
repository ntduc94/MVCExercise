﻿using BOL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public static class WorkerDAL
    {
        public static DataSet ReturnWorkerDataSet(string strConnec)
        {

            using (var sqlcon = new SqlConnection(strConnec))
            {
                var dataSet = new DataSet();
                new SqlDataAdapter("select * from Worker", sqlcon).Fill(dataSet);
                return dataSet;
            }
        }
        public static DataTable ReturnWorkerDataTable(string strConnec)
        {

            using (var sqlcon = new SqlConnection(strConnec))
            {
                var dataSet = new DataSet();
                new SqlDataAdapter("select * from Worker", sqlcon).Fill(dataSet);
                return dataSet.Tables[0];
            }
        }

        public static int AddWorker(string strConnect, Worker worker)
        {
            using (var conn = new SqlConnection(strConnect))
            {
                var command = new SqlCommand()
                {
                    CommandText = "InsertWorker",
                    CommandType = CommandType.StoredProcedure,
                    Connection = conn,
                    Parameters =
                    {
                        new SqlParameter("@Id", worker.Id),
                        new SqlParameter("@Name", worker.Name),
                        new SqlParameter("@Age", worker.Age),
                        new SqlParameter("@Salary", worker.Salary),
                        new SqlParameter("@WorkLocation", worker.WorkLocation)
                    }
                };
                conn.Open();
                return command.ExecuteNonQuery();
            }
        }

        public static int UpdateWorker(string strConnect, Worker worker)
        {
            using (var conn = new SqlConnection(strConnect))
            {
                var command = new SqlCommand()
                {
                    CommandText = "UpdateWorker",
                    CommandType = CommandType.StoredProcedure,
                    Connection = conn,
                    Parameters =
                    {
                        new SqlParameter("@Id", worker.Id),
                        new SqlParameter("@Name", worker.Name),
                        new SqlParameter("@Age", worker.Age),
                        new SqlParameter("@Salary", worker.Salary),
                        new SqlParameter("@WorkLocation", worker.WorkLocation)
                    }
                };
                conn.Open();
                return command.ExecuteNonQuery();
            }
        }

        //public int DeleteWorker(string strConnect, Worker worker)
        //{
        //    using (var conn = new SqlConnection(strConnect))
        //    {
        //        var command = new SqlCommand()
        //        {
        //            CommandText = "insertWorker",
        //            CommandType = CommandType.StoredProcedure,
        //            Connection = conn,
        //            Parameters =
        //            {
        //                new SqlParameter("@WorkerID", worker.WorkerID),
        //                new SqlParameter("@CompanyName", worker.CompanyName),
        //                new SqlParameter("@Address", worker.Address),
        //                new SqlParameter("@Country", worker.Country),
        //                new SqlParameter("@Phone", worker.Phone)
        //             }
        //        };
        //        conn.Open();
        //        return command.ExecuteNonQuery();
        //    }
        //}
    }
}
