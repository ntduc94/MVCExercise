﻿using System;
using System.Windows.Forms;

namespace Day4_Assignment3
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            // check form is opend?
            bool isOpen = false;
            // search opened form
            foreach (Form f in Application.OpenForms)
            {
                if(f.Text == "Form2")
                {
                    isOpen = true;
                    f.BringToFront();
                    break;
                }
            }

            if (!isOpen)
            {
                New newMDIChild = new New();
                // Set the Parent Form of the Child window.  
                newMDIChild.MdiParent = this;
                // Display the new form.  
                newMDIChild.Show();
            }
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
