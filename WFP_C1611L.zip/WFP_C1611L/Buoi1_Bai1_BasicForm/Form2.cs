﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buoi1_Bai1_BasicForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form1 = new Form1();
            //form1.Closed += (s, args) => this.Close();
            form1.FormClosed += (s, args) => this.Close();
            form1.Show();
            //Form1 form1 = new Form1();
            //form1.Show();
            //form1.ShowDialog();
            //this.Visible = true;
            //this.Hide();

            //this.Close(); // close luc chay se goi dispose(): tat nhung thang lien quan 
            //this.Dispose(); // huy tai nguyen cua no tren may
        }
    }
}
