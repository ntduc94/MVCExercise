﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //protected override void SetVisibleCore(bool value)
        //{
        //    if (!this.IsHandleCreated)
        //    {
        //        this.CreateHandle();
        //        value = false;
        //    }
        //    base.SetVisibleCore(value);
        //}
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Form f = new Form();
            //f.MdiParent = this;
            //f.Show();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.Close();
        }

        private void cascadeWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //About about = new About();
            //about.Show();
        }

        [DllImport("user32.dll")]
        public static extern void LockWorkStation();
        private void sleepToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //LockWorkStation();
        }

        private void hideIconToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //notifyIcon1.ShowBalloonTip(500);
            //this.Visible = false;
            //notifyIcon1.Visible = true;
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //notifyIcon1.Visible = false;
            //this.Visible = true;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            //if (FormWindowState.Minimized == this.WindowState)
            //{
            //    notifyIcon1.Visible = true;
            //    notifyIcon1.ShowBalloonTip(500);
            //    this.Hide();
            //}
            //else if (FormWindowState.Normal == this.WindowState)
            //{
            //    notifyIcon1.Visible = false;
            //}
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.Hide();
            //this.Visible = false;
            //this.Visible = false;
            //this.Hide();
            about = new About();
            about.Show();
            
        }
        public About about;
        private void Form1_VisibleChanged(object sender, EventArgs e)
        {
            //base.SetVisibleCore(true);
            //base.SetVisibleCore(false);ftyftxd
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            about.Close();
            MessageBox.Show("about close");
        }
    }
}
