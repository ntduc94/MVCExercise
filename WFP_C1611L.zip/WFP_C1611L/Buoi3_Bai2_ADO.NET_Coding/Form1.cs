﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Configuration;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Buoi3_Bai2_ADO.NET_Coding
{
    public partial class Form1 : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter dataAdapter = new SqlDataAdapter();
        DataSet dataSet = new DataSet();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        // khi load Form ko nên bỏ dữ liệu vào vì load lâu, nên load giao diện trc rồi đổ dữ liệu giới hạn theo ngày tháng
        private void button1_Click(object sender, EventArgs e)
        {
            // nhưng cách cũ ko xài nữa
            // khi build ra file exe hoặc dll thì ko sửa dc
            // nên ta thay bằng file App.config, mỗi lần sửa tên db hoặc tên SQL gì đó quên r thì vào đây
            // nhưng App.config có nhược điểm là lộ thông tin vì nodepad cug có thể mở
            // thầy nói file dll hoặc exe ai bảo ko mở dc, thầy mở dễ như kêu á á còn j :v
            // và .net lại có 1 bộ mã hóa cho file App.config nhưng mà trình chưa tới thầy chưa chỉ
            //connection.ConnectionString = "Data Source=DESKTOP-H21ICMS\MONSTERSHOWER;Initial Catalog=C1611L;Persist Security Info=True;User ID=sa;Password=1235"; 

            connection.ConnectionString = ConfigurationManager.ConnectionStrings["C1611LConn"].ConnectionString;

            command.Connection = connection;
            command.CommandText = "select * from StudentC1611L"; // c# phân biệt hoa thường
            command.CommandType = CommandType.Text; // tự động c# đoán store hay text, nhưng chỉ ra trc thì load nhanh hơn
            command.CommandTimeout = 30; // bên dưới client ko tác dụng, nhưng có td bên server (mặc định sv chỉ cho 1-2s để lấy dữ liệu - do kết nối lâu quá sẽ chết sv) 
            dataAdapter.SelectCommand = command; // tui sẽ thực thi câu này, phân vùng cho tui
            if (dataSet.Tables.Count > 0) dataSet.Tables[0].Clear(); // nếu để .Tables. thì sẽ clear hết grid, thay bằng Table[0] để chỉ xóa current table
            dataAdapter.Fill(dataSet); // phân vùng xong, kẻ bảng
            // Debugger.Break(); // debug cách 1
            dataGridView1.DataSource = dataSet.Tables[0].DefaultView;
        } // debug cách 2

        private void button2_Click(object sender, EventArgs e)
        {
            //connection.ConnectionString = "Data Source=DESKTOP-H21ICMS\MONSTERSHOWER;Initial Catalog=C1611L;Persist Security Info=True;User ID=sa;Password=1235"; // nhưng cách cũ ko xài nữa
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["C1611LConn"].ConnectionString;

            command.Connection = connection;
            command.CommandText = "GetAllStudentC1611L"; // c# phân biệt hoa thường
            command.CommandType = CommandType.StoredProcedure; // tự động c# đoán store hay text, nhưng chỉ ra trc thì load nhanh hơn
            command.CommandTimeout = 30; // bên dưới client ko tác dụng, nhưng có td bên server (mặc định sv chỉ cho 1-2s để lấy dữ liệu - do kết nối lâu quá sẽ chết sv) 
            dataAdapter.SelectCommand = command; // tui sẽ thực thi câu này, phân vùng cho tui
            if (dataSet.Tables.Count > 0) dataSet.Tables[0].Clear(); // nếu để .Tables. thì sẽ clear hết grid, thay bằng Table[0] để chỉ xóa current table, sử dụng count để
            dataAdapter.Fill(dataSet); // phân vùng xong, kẻ bảng
            // Debugger.Break(); // debug cách 1
            dataGridView1.DataSource = dataSet.Tables[0].DefaultView;
        } // debug cách 2

        private void button3_Click(object sender, EventArgs e)
        {
            // khi .net sử dụng select ko open và close
            // select thì ko cần open close
            // sửa dữ liệu thì mới cần

            // sử dụng constructor 
            string str = ConfigurationManager.ConnectionStrings["C1611LConn"].ConnectionString;
            //SqlConnection connection = new SqlConnection(str); // ko cần
            //SqlCommand command = new SqlCommand("select * from StudentC1611L", connection); // ko cần
            //SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from StudentC1611L", str); // ko cần
            //var dataAdapter = new SqlDataAdapter("select * from StudentC1611L", str); // ko cần
            DataSet dataSet = new DataSet();
            new SqlDataAdapter("select * from StudentC1611L", str).Fill(dataSet); // rút gọn, tránh tạo đối tượng
            dataGridView1.DataSource = dataSet.Tables[0].DefaultView;
            // hết phim
        }
    }
}
