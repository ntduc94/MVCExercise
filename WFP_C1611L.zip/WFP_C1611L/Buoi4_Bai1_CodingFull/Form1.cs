﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Buoi4_Bai1_CodingFull
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet dataSet = new DataSet();

        private void Form1_Load_1(object sender, EventArgs e)
        {
            LoadData();
            AddBindingTextbox();
        }

        private void LoadData()
        {
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString;
            command.Connection = connection;
            command.CommandText = "select * from Customer;select * from Orders";
            command.CommandType = CommandType.Text;
            adapter.SelectCommand = command;
            adapter.Fill(dataSet);
            //dataGridView1.DataSource = dataSet.Tables[0].DefaultView;

            // do vao bindingsource
            // binding đứng giữa giao tiếp với table và navigator
            bindingSource1.DataSource = dataSet.Tables[0].DefaultView;
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
        }

        private void AddBindingTextbox()
        {
            textBox1.DataBindings.Add("Text", bindingSource1, "CustomerID");
            textBox2.DataBindings.Add("Text", bindingSource1, "CompanyName");
            textBox3.DataBindings.Add("Text", bindingSource1, "Address");
            textBox4.DataBindings.Add("Text", bindingSource1, "Phone");
            textBox5.DataBindings.Add("Text", bindingSource1, "Country");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            // dataSet.Tables[0].DefaultView <=> select * from Customer
            // dataSet.Tables[0].DefaultView.RowFilter <=> select * from Customer where
            dataSet.Tables[0].DefaultView.RowFilter = $"CustomerID like '%{txtSearch.Text}%'";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                //textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                dataSet.Tables[1].DefaultView.RowFilter = $"CustomerID = '{dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString()}'";
                dataGridView2.DataSource = dataSet.Tables[1].DefaultView;
            }
        }

        private void UpdateNormal_Btn_Click(object sender, EventArgs e)
        {
            command.CommandText = $"Update Customer set CompanyName='{textBox2.Text}', Address='{textBox3.Text}', Phone = '{textBox4.Text}', Country = '{textBox5.Text}' where CustomerID='{textBox1.Text}'";
            connection.Open();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
                dataSet.Tables[0].Clear();
                LoadData();
            }
        }

        private void UpdateWithParameters_Btn_Click(object sender, EventArgs e)
        {
            command.CommandText = $"Update Customer set CompanyName = @CompanyName, Address = @Address, Phone = @Phone, Country = @Country where CustomerID = @CustomerID";
            command.Parameters.AddWithValue("@CompanyName", textBox2.Text);
            command.Parameters.AddWithValue("@Address", textBox3.Text);
            command.Parameters.AddWithValue("@Phone", textBox4.Text);
            command.Parameters.AddWithValue("@Country", textBox5.Text);
            command.Parameters.AddWithValue("@CustomerID", textBox1.Text);
            connection.Open();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
                command.Parameters.Clear();
                dataSet.Tables[0].Clear();
                LoadData();
            }
        }

        private void UpdateWithUsing_Btn_Click(object sender, EventArgs e)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString))
            {
                // với using chỉ việc open vào còn close để nó lo
                var command = new SqlCommand
                {
                    CommandText = "updateCustomer",
                    CommandType = CommandType.StoredProcedure,
                    Connection = conn,
                    Parameters =
                    {
                        new SqlParameter("@CompanyName", textBox2.Text),
                        new SqlParameter("@Address", textBox3.Text),
                        new SqlParameter("@Phone", textBox4.Text),
                        new SqlParameter("@Country", textBox5.Text),
                        new SqlParameter("@CustomerID", textBox1.Text)
                    }
                };
                //command.Connection = conn;
                //command.Parameters.AddWithValue("@CompanyName", textBox2.Text);
                //command.Parameters.AddWithValue("@Address", textBox3.Text);
                //command.Parameters.AddWithValue("@Phone", textBox4.Text);
                //command.Parameters.AddWithValue("@Country", textBox5.Text);
                //command.Parameters.AddWithValue("@CustomerID", textBox1.Text);
                conn.Open();
                command.ExecuteNonQuery();
                dataSet.Tables[0].Clear();
                LoadData();
            }
        }

        private void UpdateNormalWithStore_Click(object sender, EventArgs e)
        {
            command.CommandText = "updateCustomer";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@CompanyName", textBox2.Text);
            command.Parameters.AddWithValue("@Address", textBox3.Text);
            command.Parameters.AddWithValue("@Phone", textBox4.Text);
            command.Parameters.AddWithValue("@Country", textBox5.Text);
            command.Parameters.AddWithValue("@CustomerID", textBox1.Text);
            connection.Open();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
                command.Parameters.Clear();// ko update lan 2 dc
                dataSet.Tables[0].Clear();
                LoadData();
            }
        }

        private void BtnUpdateByDA_Click(object sender, EventArgs e)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString))
            {
                // mở ra để cho adapter nhìn xuống cấu trúc bảng
                conn.Open();
                // chỉ cho DA thấy cấu trúc bảng dữ liệu, chứ nó ko lấy dữ liệu từ bảng về
                SqlDataAdapter da = new SqlDataAdapter("Select * from Customer", conn);
                // SqlCommandBuilder để tự động tạo câu query nếu dataSet thay đổi
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                // Kiểm tra khi thực thi câu query nếu bị lỗi thì trả lại dữ liệu như ban đầu
                SqlTransaction transaction = conn.BeginTransaction();
                da.SelectCommand.Transaction = transaction;
                try
                {
                    da.Update(dataSet.Tables[0]);
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    transaction.Rollback();
                }
            }
        }

    }
}
