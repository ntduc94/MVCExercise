﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Buoi_5_Bai_1_BO;
using System.Text;

using System.Threading.Tasks;

namespace Buoi_5_Bai_01_DAL
{
    public class CustomerDAL
    {
        public DataSet ReturnCustomerByDataSet(string strConnec)
        {

            using (var sqlcon = new SqlConnection(strConnec))
            {
                //var dataSet = new DataSet();
                //var da = new SqlDataAdapter("select * from Customer", sqlcon);// nhin xuong cau truc bang dua len bo nho 
                //da.Fill(dataSet);

                var dataSet = new DataSet();
                new SqlDataAdapter("select * from Customer", sqlcon).Fill(dataSet);
                return dataSet;
            }
        }
        public DataTable ReturnCustomerByDataTable(string strConnec)
        {

            using (var sqlcon = new SqlConnection(strConnec))
            {
                //var dataSet = new DataSet();
                //var da = new SqlDataAdapter("select * from Customer", sqlcon);// nhin xuong cau truc bang dua len bo nho 
                //da.Fill(dataSet);

                var dataSet = new DataSet();
                new SqlDataAdapter("select * from Customer", sqlcon).Fill(dataSet);
                return dataSet.Tables[0];
            }
        }

        public int CustomerPlus(string strConnect, CustomerBO Cus)
        {
            using (var conn = new SqlConnection(strConnect))
            {
                var command = new SqlCommand()
                {
                    CommandText = "insertCustomer",
                    CommandType = CommandType.StoredProcedure,
                    Connection = conn,
                    Parameters =
                    {
                        new SqlParameter("@CustomerID", Cus.CustomerID),
                        new SqlParameter("@CompanyName", Cus.CompanyName),
                        new SqlParameter("@Address", Cus.Address),
                        new SqlParameter("@Country", Cus.Country),
                        new SqlParameter("@Phone", Cus.Phone)
                     }
                };
                conn.Open();
                return command.ExecuteNonQuery();
            }

        }
    }
}
