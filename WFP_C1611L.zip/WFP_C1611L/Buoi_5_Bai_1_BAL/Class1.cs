﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Buoi_5_Bai_01_DAL;
using System.Threading.Tasks;
using Buoi_5_Bai_1_BO;
using System.Data;

namespace Buoi_5_Bai_1_BAL
{
    public class CustomerBAL
    {
        public DataSet ReturnCustomerByDataSet(string strConnec)
        {
            var customer = new CustomerDAL();
            return customer.ReturnCustomerByDataSet(strConnec);
           
        }
        public DataTable ReturnCustomerByDataTable(string strConnec)
        {
            var customer = new CustomerDAL();
            return customer.ReturnCustomerByDataTable(strConnec);

        }
        public int CustomerPlus(string strConnect,CustomerBO Cus)
        {
            return new CustomerDAL().CustomerPlus(strConnect, Cus);

        }
    }
}
