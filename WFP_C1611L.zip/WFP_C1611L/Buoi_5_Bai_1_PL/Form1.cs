﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Configuration;
using Buoi_5_Bai_1_BAL;
using System.Threading.Tasks;
using Buoi_5_Bai_1_BO;
using System.Windows.Forms;

namespace Buoi_5_Bai_1_PL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LoadCustomer(object sender, EventArgs e)
        {
            //string connec =
            //    ConfigurationManager.ConnectionStrings["MB"].ConnectionString;
            //var customer = new CustomerDAL();
            //bindingSource1.DataSource =
            //    customer.ReturnCustomerByDataSet(connec).Tables[0].DefaultView;
            //bindingNavigator1.BindingSource = bindingSource1;
            //dataGridView1.DataSource = bindingSource1;

            //string connec =
            //  ConfigurationManager.ConnectionStrings["MB"].ConnectionString;
            //var customer = new CustomerDAL();
            //bindingSource1.DataSource =
            //    customer.ReturnCustomerByDataTable(connec).DefaultView;
            //bindingNavigator1.BindingSource = bindingSource1;
            //dataGridView1.DataSource = bindingSource1;

            string connec =
              ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString;
            var customer = new CustomerBAL();
            bindingSource1.DataSource =
                customer.ReturnCustomerByDataTable(connec).DefaultView;
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
        }

        private void AddCustomer(object sender, EventArgs e)
        {
            string connec =
             ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString;
            var customer = new CustomerBAL();
            var customerBO = new CustomerBO()
            {
                CustomerID = textBox1.Text,
                CompanyName = textBox2.Text,
                Address = textBox3.Text,
                Country = textBox4.Text,
                Phone = textBox5.Text,
            };
            if(customer.CustomerPlus(connec, customerBO) > 0)
            {
                MessageBox.Show("Thanh Cong", "Thong Bao",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }
        //business ACCESS LAYER, B- logic-L
    }
}
