﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Buoi4
{
    class Class1
    {
        static void Main(string[] args)
        {
            // $selected$ la nhu nay
            // an ctrl K X
            while (true)
            {
                Console.WriteLine("123");
            }
            // con cai $bien$ la no to den cho minh sua
            // trc khi chỉnh sửa snippet nên chạy visual studio bằng run as admin nha
            while (true)
            {
                // rồi cơ bản nó có z
                // còn nhiều hơn thì vào gg
                // tìm cái snippet referen
                // nhớ chọn phiên bản mới nhất
                // trong đây có tất cả cái j của snippet :v
            }

            //bây giờ chỉnh sửa lại cái cw :v
            // nó hơi bị ức chế :v
            Console.WriteLine();
            // Editable = "false"
            // nó có nghĩa là ko cho chỉnh sửa biến
            // ngon :v
            // cw cu no z :v
            Console.WriteLine(abc);
            // xuogn dong cug dc
            // shift enter
            Console.WriteLine();
            // ma minh de enter lun cho le:v
            // hay để nó phía sau thế này :v
            Console.WriteLine(string);
        }
    }
}
