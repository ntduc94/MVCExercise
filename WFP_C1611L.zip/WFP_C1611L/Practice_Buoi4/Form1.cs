﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Practice_Buoi4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // tạo các thuộc tính (field) connect với SQL Server
        // trc khi tạo chúng ta cần thêm tag <connection> vào file App.config
        //<connectionStrings>
        //  <add name = "MUABANConnectionString"
        //      connectionString="Data Source=DESKTOP-H21ICMS\MONSTERSHOWER;Initial Catalog=MUABAN;Persist Security Info=True;User ID=sa;Password=1235"
        //      providerName="System.Data.SqlClient" />
        //</connectionStrings>
        // xong add reference (thư viện dll) System.Configuration
        // xong using 2 thằng dưới vào:
        //using System.Data.SqlClient;
        //using System.Configuration;
        // giờ thì tạo thuộc tính conn

        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand = new SqlCommand();
        SqlDataAdapter SqlDataAdapter = new SqlDataAdapter();
        DataSet DataSet = new DataSet();

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
            TextBoxBinding();
        }

        private void TextBoxBinding()
        {
            textBox1.DataBindings.Add("Text", bindingSource1, "CustomerID");
            textBox2.DataBindings.Add("Text", bindingSource1, "CompanyName");
            textBox3.DataBindings.Add("Text", bindingSource1, "Phone");
            textBox4.DataBindings.Add("Text", bindingSource1, "Address");
            textBox5.DataBindings.Add("Text", bindingSource1, "Country");
        }

        private void TextBoxClear()
        {
            textBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox3.Text = String.Empty;
            textBox4.Text = String.Empty;
            textBox5.Text = String.Empty;
        }

        private void LoadData()
        {
            SqlConnection.ConnectionString = ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString;
            SqlCommand.Connection = SqlConnection;
            // câu query thứ 2 sẽ hứng dữ liệu vè 1 bảng thứ 2 và bỏ vào dataset.table[1]
            // tương tự cho câu 3 cho tới n
            // cách nhau bằng dấu ;
            // giống như trong sql
            SqlCommand.CommandText = "select * from Customer; select * from Orders";
            SqlCommand.CommandType = CommandType.Text;
            SqlDataAdapter.SelectCommand = SqlCommand;
            if (DataSet.Tables.Count > 0) DataSet.Tables[0].Clear();
            SqlDataAdapter.Fill(DataSet);
            // cái này đổ dataSet vào dataGridView
            // dataGridView1.DataSource = DataSet.Tables[0].DefaultView;

            // Giờ mình xài binding
            // đầu tiên là đổ dataSet vào binding Source
            bindingSource1.DataSource = DataSet.Tables[0].DefaultView;
            // tiếp theo đổ bindingSource vào bindingNavigator
            // nghĩa là bindingSource kết nối navigator với gridview
            bindingNavigator1.BindingSource = bindingSource1;
            // rồi đổ bindingSource vào Gridview
            dataGridView1.DataSource = bindingSource1;

            // nhớ connect db vào studio visual trc
            // nhầm cái đó tạo bảng bằng tool, còn mình đang dùng code tay
        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            DataSet.Tables[0].DefaultView.RowFilter = $"CustomerID like '%{SearchTextBox.Text}%'";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // chưa có dữ liệu cho table[1]
            DataSet.Tables[1].DefaultView.RowFilter = $"CustomerID = '{dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString()}'";
            dataGridView2.DataSource = DataSet.Tables[1].DefaultView;
        }

        //private void BtnUpdate_Click_Normal(object sender, EventArgs e)
        //{
        //    SqlCommand.CommandText = $"Update Customer set CompanyName='{textBox2.Text}', Address='{textBox3.Text}', Phone = '{textBox4.Text}', Country = '{textBox5.Text}' where CustomerID='{textBox1.Text}'";
        //    SqlConnection.Open();
        //    try
        //    {
        //        SqlCommand.ExecuteNonQuery();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }
        //    finally
        //    {
        //        SqlConnection.Close();
        //        DataSet.Tables[0].Clear();
        //        LoadData();
        //    }
        //}

        //private void BtnUpdate_Click_WithParameters(object sender, EventArgs e)
        //{
        //    // nhầm nó update từ textbox chứ ko phải từ gridview
        //    SqlCommand.CommandText = $"Update Customer set CompanyName = @CompanyName, Phone = @Phone, Address = @Address, Country = @Country where CustomerID = @CustomerID";
        //    SqlCommand.Parameters.AddWithValue("@CompanyName", textBox2.Text);
        //    SqlCommand.Parameters.AddWithValue("@Phone", textBox3.Text);
        //    SqlCommand.Parameters.AddWithValue("@Address", textBox4.Text);
        //    SqlCommand.Parameters.AddWithValue("@Country", textBox5.Text);
        //    SqlCommand.Parameters.AddWithValue("@CustomerID", textBox1.Text);
        //    SqlConnection.Open();
        //    try
        //    {
        //        SqlCommand.ExecuteNonQuery();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }
        //    finally
        //    {
        //        SqlConnection.Close();
        //        SqlCommand.Parameters.Clear();
        //        DataSet.Tables[0].Clear();
        //        LoadData();
        //    }
        //}

        //private void BtnUpdate_Click_WithParametersStore(object sender, EventArgs e)
        //{
        //    SqlCommand.CommandText = $"updateCustomer";
        //    SqlCommand.Parameters.AddWithValue("@CompanyName", textBox2.Text);
        //    SqlCommand.Parameters.AddWithValue("@Phone", textBox3.Text);
        //    SqlCommand.Parameters.AddWithValue("@Address", textBox4.Text);
        //    SqlCommand.Parameters.AddWithValue("@Country", textBox5.Text);
        //    SqlCommand.Parameters.AddWithValue("@CustomerID", textBox1.Text);
        //    SqlConnection.Open();
        //    try
        //    {
        //        SqlCommand.ExecuteNonQuery();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }
        //    finally
        //    {
        //        SqlConnection.Close();
        //        SqlCommand.Parameters.Clear();
        //        DataSet.Tables[0].Clear();
        //        LoadData();
        //    }
        //}
        //private void BtnUpdate_Click_WithUsing(object sender, EventArgs e)
        //{
        //    using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString))
        //    {
        //        var command = new SqlCommand
        //        {
        //            CommandText = "updateCustomer",
        //            CommandType = CommandType.StoredProcedure,
        //            Connection = conn,
        //            Parameters =
        //            {
        //                new SqlParameter("@CompanyName", textBox2.Text),
        //                new SqlParameter("@Address", textBox3.Text),
        //                new SqlParameter("@Phone", textBox4.Text),
        //                new SqlParameter("@Country", textBox5.Text),
        //                new SqlParameter("@CustomerID", textBox1.Text)
        //            }
        //        };
        //        conn.Open();
        //        try
        //        {
        //            command.ExecuteNonQuery();
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.ToString());
        //        }
        //        DataSet.Tables[0].Clear();
        //        LoadData();
        //        // ben nay thi dc
        //        // vì đây là biết cục bộ
        //        // bên kia là biến toàn cục
        //    }
        //}

        private void BtnUpdate_Click_WithUsingByDataAdapter(object sender, EventArgs e)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString))
            {
                conn.Open();
                var da = new SqlDataAdapter("select * from Customer", conn);
                var cmBuilder = new SqlCommandBuilder(da);
                var trans = conn.BeginTransaction();
                da.SelectCommand.Transaction = trans;
                try
                {
                    da.Update(DataSet.Tables[0]);
                    trans.Commit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    trans.Rollback();
                }
            }
            //using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MUABANConnectionString"].ConnectionString))
            //{
            //    var command = new SqlCommand
            //    {
            //        CommandText = "insertCustomer",
            //        CommandType = CommandType.StoredProcedure,
            //        Connection = conn,
            //        Parameters =
            //            {
            //                new SqlParameter("@CustomerID", textBox1.Text),
            //                new SqlParameter("@CompanyName", textBox2.Text),
            //                new SqlParameter("@Address", textBox3.Text),
            //                new SqlParameter("@Country", textBox5.Text),
            //                new SqlParameter("@Phone", textBox4.Text)
            //            }
            //    };
            //    conn.Open();
            //    try
            //    {
            //        command.ExecuteNonQuery();
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.ToString());
            //    }
            //    DataSet.Tables[0].Clear();
            //LoadData();
            //TextBoxClear();
            //}
        }
    }
}
